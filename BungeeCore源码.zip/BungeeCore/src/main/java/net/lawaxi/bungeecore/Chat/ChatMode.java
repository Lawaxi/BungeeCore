package net.lawaxi.bungeecore.Chat;

public enum ChatMode {
    PUBLIC,PARTY
}
